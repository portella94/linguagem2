
package Entidades;

public class Usuario {
    
}
