package Shared;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class saxParser {
    private String caminho = null;
    private Map<String, String> tmpAtrb = null;
    private Map<String, String> xmlVal = new LinkedHashMap<String, String>();

    public  void main(String[] args) throws ParserConfigurationException, SAXException, IOException, VerifyError {

        /**
         * We can pass the class name of the XML parser to the
         * SAXParserFactory.newInstance().
         */
        //SAXParserFactory saxDoc = SAXParserFactory.newInstance("com.sun.org.apache.xerces.internal.jaxp.SAXParserFactoryImpl", null);
        SAXParserFactory saxDoc = SAXParserFactory.newInstance();
        SAXParser saxParser = saxDoc.newSAXParser();

        DefaultHandler handler = new DefaultHandler() {
            String tmpElementName = null;
            String tmpElementValue = null;

            @Override
            public void startElement(String uri, String localName, String qName,
                    Attributes attributes) throws SAXException {
                tmpElementValue = "";
                tmpElementName = qName;
                tmpAtrb = new HashMap();
                //System.out.println("Start Element :" + qName);
                /**
                 * Store attributes in HashMap
                 */
                for (int i = 0; i < attributes.getLength(); i++) {
                    String aname = attributes.getLocalName(i);
                    String value = attributes.getValue(i);
                    tmpAtrb.put(aname, value);
                }

            }

            @Override
            public void endElement(String uri, String localName, String qName)
                    throws SAXException {

                if (tmpElementName.equals(qName)) {
                    System.out.println("Element Name :" + tmpElementName);
                    /**
                     * Retrive attributes from HashMap
                     */
                    for (Map.Entry<String, String> entrySet : tmpAtrb.entrySet()) {
                        System.out.println("Attribute Name :" + entrySet.getKey() + "Attribute Value :" + entrySet.getValue());
                    }
                    System.out.println("Element Value :" + tmpElementValue);
                    xmlVal.put(tmpElementName, tmpElementValue);
                    System.out.println(xmlVal);
                    //Fetching The Values From The Map
                    String getKeyValues = xmlVal.get(tmpElementName);
                    System.out.println("XmlTag:" + tmpElementName + ":::::" + "ValueFetchedFromTheMap:" + getKeyValues);
                }
            }

            @Override
            public void characters(char ch[], int start, int length) throws SAXException {
                tmpElementValue = new String(ch, start, length);
            }
        };
        /**
         * Below two line used if we use SAX 2.0 Then last line not needed.
         */

        //saxParser.setContentHandler(handler);
        //saxParser.parse(new InputSource("c:/file.xml"));
        saxParser.parse(new File(caminho), handler);
    }
}
