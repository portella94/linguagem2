/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import BaseDados.ConnectionFactory;
import Entidades.Login;
import Entidades.Sessao;
import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author usrlab09
 */
public class LoginNG extends BaseNG {

    private Connection conexao;
    public LoginNG(Sessao sessao) throws Exception {
        try {
            this.conexao = ConnectionFactory.createConnection();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public LoginNG() {
    }

    //public boolean Cadastrar(Login login) throws Exception {
    //  return new BaseDados.DAOs.ProdutoDAO(conexao).Cadastrar(produto);
    //}
    public Login buscarLogin(Login login) throws Exception {
        return new BaseDados.DAOs.LoginDAO(conexao).buscarLogin(login);
    }

}
