/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BaseDados.DAOs;

import BaseDados.BaseDAO;
import Entidades.Login;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author usrlab09
 */
public class LoginDAO extends BaseDAO {

    /*
     * Construtor que recebe como parametro uma conexao com o banco de dado. 
     */
    public LoginDAO(Connection con) {
        this.con = con;
    }

    public Login buscarLogin(Login login) throws Exception {
        PreparedStatement p = con.prepareStatement("select login, senha from login where login = ? ");
        p.setString(1, login.getLogin());
        ResultSet rs = p.executeQuery();        
        if (rs.next()) {
            login.setSenha(rs.getString("senha"));
        }
        rs.close();
        p.close();
        return login;
    }

}
